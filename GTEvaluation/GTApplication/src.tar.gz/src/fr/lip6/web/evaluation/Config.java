package fr.lip6.web.evaluation;

public class Config {
    public static String mysqlHost = "localhost";
    public static String mysqlUser = "bom";
    public static String mysqlPassword = "DL77ESuQZT2a3q6X";
    public static String mysqlDatabase = "bom";
}
//public class Config {
//    public static String mysqlHost = "localhost";
//    public static String mysqlUser = "root";
//    public static String mysqlPassword = "c2306hytu";
//    public static String mysqlDatabase = "bom";
//}
