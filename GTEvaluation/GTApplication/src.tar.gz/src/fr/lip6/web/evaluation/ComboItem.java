package fr.lip6.web.evaluation;

public class ComboItem {
    String key="";
    String value="";
    public ComboItem(String key,String value) {
        this.key = key;
        this.value = value;
    }
}
