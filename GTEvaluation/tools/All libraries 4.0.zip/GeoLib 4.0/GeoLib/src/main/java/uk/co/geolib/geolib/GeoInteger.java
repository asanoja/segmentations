package uk.co.geolib.geolib;

public class GeoInteger {
	
	public GeoInteger(int i) {
		value = i;
	}
	public int value;
}
