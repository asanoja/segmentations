package uk.co.geolib.geolib;

public class GeoDouble {
	public GeoDouble(double d) {
		value = d;
	}

	public double value;
}
