<?php
$data = new SQLite3("data/results.db");
$data->exec("delete from metrics")
?>
Deleted all metrics
