<script>
window.onload = function() {parent.dataLoaded();}
</script>
<?php
$GLOBALS['trow']=-1;

function fmt($s) {
	$col=1;
	$GLOBALS['trow']++;
	$d=explode(",",$s);
	$f="<tr align='center'>";
	
	for ($i=0;$i<count($d);$i++) {
		$f=$f."<td id='r".$GLOBALS['trow']."c".$col."' row='".$GLOBALS['trow']."' col='".$col."'>".$d[$i]."</td>";
		$col++;
	}
	$f=$f."</tr>";
	return $f;
}

$filename = $_GET['source'];
$filter=true;
if ($_GET['filter']=="") $filter=false;
$qfilter = trim($_GET['filter']);

//~ $handle = @fopen("/web/sanojaa/public_html/SCAPE/".$filename . ".txt", "r");
//~ $handle = @fopen("/var/www/BOM/data/".$filename . ".txt", "r");
$data = new SQLite3("data/".$filename.".db");
echo $filename . " for " . $qfilter;
if ($data) {
	echo "<table border='1'>";
	$sql="select * from blocks where url='".$qfilter."'";
	//~ echo $sql;
	$results = $data->query($sql); 
    while ($row = $results->fetchArray()) {
		$s = $row[1].",".$row[2].",".$row[3].",".$row[4].",".$row[5].",".$row[6].",".$row[7].",".$row[8].",".$row[9].",".$row[10];
		echo fmt($s);
    }
    echo "</table>";
    $data->close();
}
?>

