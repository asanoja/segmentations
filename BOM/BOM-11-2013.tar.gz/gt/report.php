<?php	
$variable = $_GET["val"];
if (!isset($variable)) $variable="tc";
$title = [
	'tc'=>'Total correct blocks',
	'cm'=>'Missed blocks',
	'cf'=>'False Alarms blocks',
	'to'=>'Total oversegmented blocks',
	'tu'=>'Total undersegmented blocks'
];

	function tabular($sql,$fields) {
		$data = new SQLite3("../data/results.db");	
		echo "<table border=1>";
		echo "	<tr>";
		for ($f=0;$f<count($fields);$f++) {
			echo "<td><b>".$fields[$f]."</b></td>";
		}
		echo "	</tr>";
		$results = $data->query($sql);
		while ($row = $results->fetchArray()) {
			echo "<tr>";
			for ($i=0;$i<count($fields);$i++) {
				echo "<td>".$row[$i]."</td>";
			}
			echo "</tr>";
		}
		$data->close();
		echo "</table>";
		$data->close();
	}
?>

<html>
	<head>
		<script src="graphs/amcharts/amcharts.js" type="text/javascript"></script>
        <script src="graphs/amcharts/xy.js" type="text/javascript"></script>
        <title>Evaluation Report</title>
        <script>
        function go(k) {
			location.href = "report.php?val="+k;
		}
        </script>
        <script>
        var chart;
        
         var chartData = [
			<?php 
				$data = new SQLite3("../data/results.db");	
				$sql="select count(distinct url),algorithms.name,category,tt,avg(tc),avg('to'),avg(tu),avg(co),avg(cu),avg(cm),avg(cf), avg(gtb), avg(stb), avg(tc)/avg(gtb) as prec, ((avg(tc)/avg(gtb)) / (avg(cm)+avg(cf))) as score  from metrics inner join algorithms on algorithms.id=algorithm group by category,algorithm,tt order by category,algorithm,tt;";
				//~ $sql_tc="select category,tt,avg(tc) from metrics inner join algorithms on algorithms.id=algorithm group by category,algorithm,tt order by category,algorithm,tt;";
				$sql_master="select category,tt from metrics group by category,tt order by category,tt;";
				$master = $data->query($sql_master); 
				
				//~ while ($cat = $master->fetchArray()) {
					for ($tt=0;$tt<=25;$tt+=5) {
						$sql_r="select algorithm,avg(metrics.'".$variable."') from metrics where algorithm=1 and tt=".$tt." group by tt;";
						$detail = $data->query($sql_r); 
						echo "{";
						if ($r = $detail->fetchArray()) {
							echo "'bomx':".$tt.",";
							echo "'bomy':".$r[1].",";
							echo "'algo1':'BOM'";
						}
						 $sql_r="select algorithm,avg(metrics.'".$variable."') from metrics where algorithm=2 and tt=".$tt." group by tt;";
						$detail = $data->query($sql_r); 
						if ($r = $detail->fetchArray()) {
							echo ",'vipsx':".$tt.",";
							echo "'vipsy':".$r[1].",";
							echo "'algo2':'VIPS'";
							
						}
						echo "}";
						if ($tt<25) echo ",\n";
					}
            //~ }
            $data->close();
            ?>
               
            ];

        AmCharts.ready(function () {
                // XY CHART
                chart = new AmCharts.AmXYChart();
                chart.pathToImages = "graphs/amcharts/images/";
                chart.dataProvider = chartData;
                chart.startDuration = 1;

                // AXES
                // X
                var xAxis = new AmCharts.ValueAxis();
                xAxis.title = "Tolerance (px)";
                xAxis.position = "bottom";
                xAxis.dashLength = 1;
                xAxis.axisAlpha = 0;
                xAxis.autoGridCount = true;
                chart.addValueAxis(xAxis);

                // Y
                var yAxis = new AmCharts.ValueAxis();
                yAxis.position = "left";
                yAxis.title = "Blocks (avg)";
                yAxis.dashLength = 1;
                yAxis.axisAlpha = 0;
                yAxis.autoGridCount = true;
                chart.addValueAxis(yAxis);

                // GRAPHS
                // triangles up			
                var graph1 = new AmCharts.AmGraph();
                graph1.lineColor = "#FF6600";
                graph1.title = "1. BOM";
                graph1.balloonText = "x:[[x]] y:[[y]]";
                graph1.xField = "bomx";
                graph1.yField = "bomy";
                graph1.lineAlpha = 100;
                graph1.bullet = "circle";
                //~ graph1.valueField = "[[algo1]]";
                //~ graph1.legendValueText="[[algo1]]";
                chart.addGraph(graph1);

                // triangles down 
                var graph2 = new AmCharts.AmGraph();
                graph2.lineColor = "#FCD202";
                graph2.title = "2. VIPS";
                graph2.balloonText = "x:[[x]] y:[[y]]";
                graph2.xField = "vipsx";
                graph2.yField = "vipsy";
                graph2.lineAlpha = 100;
                graph2.bullet = "circle";
                //~ graph2.valueField = "[[algo1]]";
                //~ graph2.legendValueText="[[algo2]]";
                chart.addGraph(graph2);

                // first trend line
                //~ var trendLine = new AmCharts.TrendLine();
                //~ trendLine.lineColor = "#FF6600";
                //~ trendLine.initialXValue = 1;
                //~ trendLine.initialValue = 2;
                //~ trendLine.finalXValue = 12;
                //~ trendLine.finalValue = 11;
                //~ chart.addTrendLine(trendLine);
//~ 
                //~ // second trend line
                //~ trendLine = new AmCharts.TrendLine();
                //~ trendLine.lineColor = "#FCD202";
                //~ trendLine.initialXValue = 1;
                //~ trendLine.initialValue = 1;
                //~ trendLine.finalXValue = 12;
                //~ trendLine.finalValue = 19;
                //~ chart.addTrendLine(trendLine);


				var legend = new AmCharts.AmLegend();
                legend.markerType = "circle";
                legend.markerSize = 20;
                //~ legend.valueText = "[[value]]";
                chart.addLegend(legend);
                
                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chart.addChartCursor(chartCursor);

                // SCROLLBAR

                var chartScrollbar = new AmCharts.ChartScrollbar();
                chart.addChartScrollbar(chartScrollbar);

                // WRITE                                                
                chart.write("chartdiv");
            });
        </script>
	</head>
<body>
	<img src="../images/gtlogo.png" height="64">
<h1>Segmentation Evaluation Report</h1>
<form action="report.php" method="get">
<select name="val">
	<?php foreach ($title as $key => $value) {?>
		<?php if ($key == $variable) {$sel=" selected ";} else {$sel="";}?>
		<option <?=$sel?> value='<?=$key?>'><?=$value?> (<?=$key?>)</option>
	<?php }?>
</select><input type="submit" value="show"></form>
<h2><?php echo $title[$variable]?></h2>
 <div id="chartdiv" style="width: 600px; height: 400px;"></div>
 <div>
	 <?php tabular("select algorithm,tt,metrics.'".$variable."' from metrics inner join algorithms on algorithms.id=metrics.algorithm group by algorithm,tt order by algorithm,tt",['algorithm','tt',$variable])?>
 </div>
</body>
</html>
