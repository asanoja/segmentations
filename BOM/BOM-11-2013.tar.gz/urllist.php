<?php
header('Content-Type: application/javascript; charset=utf-8');
?>
urls = [<?php
$filename = "data/GTdata.db";
$data = new SQLite3($filename);
$sql = "select distinct url from blocks order by url";
$results = $data->query($sql);
  while ($row = $results->fetchArray()) {
	  echo "'".$row[0]."',";
  }
?>
];
