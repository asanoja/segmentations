<?php
function get($key) {
	return($_GET[$key]);
}

$url = get('url');
$cat = get('category');
$tc = get('tc');
$to = get('to');
$tu = get('tu');
$co = get('co');
$cu = get('cu');
$cf = get('cf');
$cm = get('cm');
$tt = get('tt');
$algo = get('algorithm');
$gtb = get('gtb');
$stb = get('stb');
//~ $graph = get('graph');

if ($algo=="BOMdata") $a=1;
if ($algo=="VIPSdata") $a=2;

//~ $f = fopen("/web/sanojaa/public_html/SCAPE/results".$algo . ".txt","a");
//~ $f = fopen("/var/www/BOM/data/results".$algo . ".txt","a");
$data = new SQLite3("data/results.db");
$sql = "insert into metrics('url','category','tc','to','tu','co','cu','cm','cf','tt','gtb','stb','algorithm') values('".$url."','".$cat."','".$tc."','".$to."','".$tu."','".$co."','".$cu."','".$cm."','".$cf."','".$tt."','".$gtb."','".$stb."','".$a."');";
//~ $s = $url . "," . $cat . "," . $tc . "," . $to . "," . $tu . "," . $co . "," . $cu  . "," . $cf . "," . $cm . "," . $tt . "," . $gtb . "," . $stb . "\n";
$data->exec($sql);
echo "The data has been saved!";
//~ fwrite($f,$s);
//~ fclose($f);
$data->close();
?>

<table border="1" width="100%">
	<tr align="center">
		<td><b>Page</b></td>
		<td><b>Algorithm</b></td>
		<td><b>GT blocks</b></td>
		<td><b>Seg Blocks</b></td>
		<td><b>TT</b></td>
		<td><b>Tc</b></td>
		<td><b>To</b></td>
		<td><b>Tu</b></td>
		<td><b>Co</b></td>
		<td><b>Cu</b></td>
		<td><b>Cm</b></td>
		<td><b>Cf</b></td>
	</tr>
	<tr align="center">
		<td><?=$url?></td>
		<td><?=$algo?></td>
		<td><?=$gtb?></td>
		<td><?=$stb?></td>
		<td><?=$tt?></td>
		<td><?=$tc?></td>
		<td><?=$to?></td>
		<td><?=$tu?></td>
		<td><?=$co?></td>
		<td><?=$cu?></td>
		<td><?=$cm?></td>
		<td><?=$cf?></td>
	</tr>
</table>
