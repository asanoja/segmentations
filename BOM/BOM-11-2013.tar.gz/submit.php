<?php
$name = trim($_REQUEST['name']);
$page = urldecode(trim($_REQUEST['page']));
$category = trim($_REQUEST['category']);
$total = intval(trim($_REQUEST['total']));
$meta = trim($_REQUEST['meta']);
$source = trim($_REQUEST['source']);
if ($source=="GTdata") $logo="logo.png";
if ($source=="BOMdata") $logo="logo_bom.png";
?>
<html>
	<head>
		<title>Thanks for your submission</title>
	</head>
	<body>
		<table width='100%'>
	<tr>
		<td><img src="images/<?=$logo?>" height='150'></td>
		<td><img src="images/logo_lip6.png" height='100'></td>
		<td><img src="images/LogoUPMC3.png" height='100'></td>
		<td><img src="images/SCAPE_logo_thumb.jpg" height='100'></td>
	</tr>
</table>
<h1>Thanks for your submission</h1>

Here the submission data:<br>
<ul>
<li>Page <a href='<?=$page?>' target='new'><?=$page?></a></li>
<li>Data stored in <?=$source?>.db</li>
<li>Blocks submited:</li>
<table border=1>
	<tr align="center"><td><b>Browser</b></td><td><b>Document geometry</b></td><td><b>Block ID</b></td><td><b>Block geometry</b></td></tr>
<?php
$title = $page;
$pp = explode(" ",$meta);
$browser = $pp[0];
$dim = $pp[1];
$xdim = explode("x",$pp[1]);
$dw = $xdim[0];
$dh = $xdim[1];

$blocks = Array();
try {
for ($i=1;$i<=$total;$i++) {
	$b = $_REQUEST["block".$i];
	if (trim($b)!="") {
		array_push($blocks,trim($b));
	}
}

//~ $filename = "/web/sanojaa/public_html/SCAPE/".$source.".txt";
$filename = "data/".$source.".db";
$data = new SQLite3($filename);
$sort = [];
$payload="";
for ($i=0;$i<count($blocks);$i++) {
	//echo $i."-".$blocks[$i];
	$dim = explode(",",$blocks[$i]);
	$id = $dim[0];
	if (trim($id)!="")  {
		$left = $dim[1];
		$top = $dim[2];
		$width = $left+$dim[3];
		$height = $top+$dim[4];
		$sql = "insert into blocks(browser,category,url,doc_w,doc_h,bid,block_x,block_y,block_w,block_h) values('".$browser."','".$category."','".$page."','".$dw."','".$dh."','".$id."','".$left."','".$top."','".$width."','".$height."')";
		echo  "<tr><td>".$browser . "</td><td>" . $dw . "x" . $dh . "</td><td>" . $id . "</td><td>" . $left . " " . $top . " " . $width . " " . $height . "</td></tr>";
		//~ array_push($sort, $payload);
		$data->exec($sql);
	}
}

$data->close();


} catch (Exception $e) {
    echo 'Exception reçue : ',  $e->getMessage(), "\n";
    exit;
}



?>
<?}?>
</table>
</ul>
</body>
</html>
