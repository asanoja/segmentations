var script = document.getElementById("script-pl-manual");

if (!script) {
    script = document.createElement('script');  
    //script.innerHTML = "alert('hello world')";
    script.id = "script-pl-manual";
    script.src ="http://localhost/pmanual.js";
    head = document.getElementsByTagName("head")[0];
    head.appendChild(script);
    alert(head.innerHTML);
    
}