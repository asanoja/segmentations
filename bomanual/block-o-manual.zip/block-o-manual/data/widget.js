var pbutton = document.getElementById("pmanual-button");

pbutton.onclick = function() {
    self.port.emit('click');
}