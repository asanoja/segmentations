var url="";

self.port.on("takeURL", function(eurl) {
    url=eurl;
});

self.port.on("takeBlock", function(blockList) {
    console.log("dep: size list "+blockList.length);
    marco = document.getElementById("marco");
	s="<form target='_blank' action='http://www-poleia.lip6.fr/~sanojaa/SCAPE/submit.php' id='pmanual_form' method='POST'>";
	s+="<ol>";
	for (var i=0;i<blockList.length;i++) {
			if (blockList[i]) {
				s+=" <li id='"+i+"'>";
                s+="<input id='"+(i+1)+"' name='block"+(i+1)+"' type='hidden' value='"+blockList[i][2]+" "+blockList[i][3]+"'>";
                s+="<span>"+blockList[i][2]+" "+blockList[i][3]+"</span>";
                s+=" <a href='#' id='"+i+"'>[X]</a>";
                s+="</li>";
			}
	}
	s+="</ol>";
    s+="<input id='pmanual_webpage' type='hidden' value='"+url+"' name='page'><br>";
	s+="<input id='pmanual_total' type='hidden' value='"+blockList.length+"' name='total'><br>";
	s+="Your name:<input id='pmanual_username' type='hidden' value='andres' name='name'><br>";
	s+="Category:<select id='pmanual_category' name='category'>";
    s+="<option value='unfiled_tagged'>Unfiled Tagged</option>";
    s+="<option value='Music_Movies'>Music_Movies</option>";
    s+="<option value='home_living'>Home Living</option>";
    s+="<option value='outdoors'>Outdoors</option>";
    s+="<option value='sci_tech'>Sci Tech</option>";
    s+="<option value='regional'>Regional</option>";
    s+="<option value='society'>Society</option>";
    s+="<option value='computers'>Computers</option>";
    s+="<option value='media'>Media</option>";
    s+="<option value='hobbies'>Hobbies</option>";
    s+="<option value='commerce'>Commerce</option>";
    s+="<option value='religion'>Religion</option>";
    s+="<option value='sports'>Sports</option>";
    s+="<option value='health'>Health</option>";
    s+="<option value='arts_history'>Arts History</option>";
	s+="</select><br>";
    
	s+="<input id='send' type='submit' value='Send'>";
	s+="</form>";
    marco.innerHTML = s;
});
