self.port.on("takeCount", function(count) {
console.log("count:"+count);
if (count==1) {
  document.getElementById("counter").innerHTML = count + " block";
} else {
    document.getElementById("counter").innerHTML = count + " blocks";
}
});